from setuptools import setup

setup(
    name="mi_paquete",
    version="0.1",
    description="Paquete de ejemplo para hacer pruebas",
    author="Juan d3bh4n5",
    author_email="juanangelbasgall@hotmail.com",
    url="d3vh4n5.com.ar",
    packages=['paquetes', 'paquetes.subpaquetes'],
    scripts=[]
)
