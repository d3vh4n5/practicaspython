def module3():
    print('Hola desde el modulo3 del subpquete del paquete')
