def modulo1():
    print('Esta es un modulo que hace cosas locas')


def modulo2():
    print('Esta es un modulo que hace cosas mas locas')